export const variables = {
    API_URL: "http://localhost:50306/api/",
    PHOTO_URL:"http://localhost:50306/Photos/"
}

